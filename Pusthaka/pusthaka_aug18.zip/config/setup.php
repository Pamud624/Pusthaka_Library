<?php
$DEBUG = false;
$db['server'] = "localhost" ;

$db['username'] = "root" ;
$db['password'] = "";
$db['database'] = "pusthaka";
?>
