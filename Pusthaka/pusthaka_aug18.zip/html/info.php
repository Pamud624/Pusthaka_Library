<?php

phpinfo();

