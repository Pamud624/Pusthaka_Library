<html>
	<head>
		<title>
		Fine Calculator
		</title>
	</head>
	<body>
		<h1> Fine Calculator </h1>
		<form action ="controller.php" method ="GET">
			<label> Date 1 : </label>
			<input type ="date" name ="dt1" id ="dt1" /> <br>
			<label> Date 2 : </label>
			<input type ="date" name ="dt2" id ="dt2" /> <br>
			
			<input type ="submit" value ="Number of Days" />
		</form>
		
		
	</body>
</html>