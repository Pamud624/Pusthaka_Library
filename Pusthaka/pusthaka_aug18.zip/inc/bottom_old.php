<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
    <td class="footer">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="footer">Pusthaka Integrated Library System</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="footer">
        <a href="http://www.pusthaka.org">pusthaka.org</a> | Version 1.1 built on 2013-02-20.
    </td>
  </tr>
</table>
