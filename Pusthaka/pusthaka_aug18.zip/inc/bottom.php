<div id="footer">
    <div class="container">
        <p class="muted credit">Pusthaka Integrated Library System | <a href="http://www.pusthaka.org">pusthaka.org</a> | Version 1.1 built on 2013-02-20.</p>
    </div>
</div>
<script src="js/gen_validatorv2.js"></script>
<script src="lib/jquery/jquery-1.7.2.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>

<!--[if IE 6]>
<script src="lib/bootstrap-ie6/bootstrap-ie.js"></script>
<![endif]-->

</body>
</html>